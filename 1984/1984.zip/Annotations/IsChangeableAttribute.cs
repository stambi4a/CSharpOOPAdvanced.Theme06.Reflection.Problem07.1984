﻿namespace _1984.Annotations
{
    using System;

    [AttributeUsage(AttributeTargets.Property)]
    public class IsChangeableAttribute : Attribute
    {

    }
}
