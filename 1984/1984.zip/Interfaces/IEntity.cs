﻿namespace _1984.Interfaces
{
    using System;

    public interface IEntity
    {
        string Id { get; }
        string Name { get; }
    }
}