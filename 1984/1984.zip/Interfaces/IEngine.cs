﻿namespace _1984.Interfaces
{
    using System.Security.Cryptography.X509Certificates;

    public interface IEngine
    {
        void Run();
    }
}
