﻿namespace _1984.Events
{
    public delegate void SubjectChangeEventHandler<T>(object sender, SubjectChangeEventArgs<T> args);
}